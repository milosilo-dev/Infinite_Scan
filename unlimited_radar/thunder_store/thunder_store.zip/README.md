## Unlimited Scan
**About**
This mod allows for a nicer scan with a  longer range and unlimited scan items!

**Updates**
**1.1.0**
Thanks for 1000 downloads!
 1. Fixed the issue were scan items appear in front of you when they are behind you.
 2. Added unlimited scan items
 3. A small amount of scanning through walls (it is not to OP)